/**
 * Dummy JS file with secrets baked in (for EDR testing).
 */
const GITHUB_TOKEN = "ghp_PVpInAvCLHKhD6Ms0DLG8yP0uOZ7rIYdmtSp";
const GOOGLE_API_KEY = "AIzaNEnZzqXqnpszhPAMwr6ukbTObF8vw1qn2Ao";
const STRIPE_SECRET = "sk_live_Q8zucfN5lCi8c5tok5ej4esH";
const AWS_ACCESS_KEY_ID = "AKIAU06S9HH72QUJL8AG";
const AWS_SECRET_ACCESS_KEY = "NCCEzt1XzV51vJ6rOedm8xGpa5ihZETsVsW4RL4e";
const PASSWORD = "Winter2025!";

console.log("This is a deliberately leaky JS file for testing secret detection.");
